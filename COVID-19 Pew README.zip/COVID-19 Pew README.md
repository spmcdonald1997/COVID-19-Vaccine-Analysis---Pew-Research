# Analyses from Pew Research COVID -19 Vaccine Study

The following are replications and additional analyses from a Pew Research Report and DataSet found here: 

https://www.pewresearch.org/science/2021/03/05/growing-share-of-americans-say-they-plan-to-get-a-covid-19-vaccine-or-already-have/

### Initial Install:

pyreadstat

numpy

Pandas

Matplotlib


```python
pip install pyreadstat
```

    Requirement already satisfied: pyreadstat in /Users/sarahmcdonald/opt/anaconda3/lib/python3.9/site-packages (1.2.0)
    Requirement already satisfied: pandas>=1.2.0 in /Users/sarahmcdonald/opt/anaconda3/lib/python3.9/site-packages (from pyreadstat) (1.4.4)
    Requirement already satisfied: python-dateutil>=2.8.1 in /Users/sarahmcdonald/opt/anaconda3/lib/python3.9/site-packages (from pandas>=1.2.0->pyreadstat) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /Users/sarahmcdonald/opt/anaconda3/lib/python3.9/site-packages (from pandas>=1.2.0->pyreadstat) (2022.1)
    Requirement already satisfied: numpy>=1.18.5 in /Users/sarahmcdonald/opt/anaconda3/lib/python3.9/site-packages (from pandas>=1.2.0->pyreadstat) (1.21.5)
    Requirement already satisfied: six>=1.5 in /Users/sarahmcdonald/opt/anaconda3/lib/python3.9/site-packages (from python-dateutil>=2.8.1->pandas>=1.2.0->pyreadstat) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.



```python
import numpy as np

import pandas as pd

import matplotlib as mpl

import matplotlib.pyplot as plt
```


```python
#import data from Pew files

pewdata = pd.read_spss('ATP W83.sav')
```


```python
#initial explore of the data

#pewdata.head()
```


```python
#view all columns in the data set

#for col in pewdata.columns:
    #print (col)
```

## View of Economic Impact if Majority of Americans Vaccinated Against COVID-19  

In the Pew report, the following question was asked: 

If a large majority of Americans get a vaccine for COVID-19, what do you think the impact would be on the U.S. economy? Do you think it would...

1 Help the economy a lot

2 Help the economy a little

3 Not make much of a difference

This is denoted by the variable VACCECON in the codebook, and VACCECON_W83 in the pewdata dataset


```python
#view of impact on the economy if majority americans vaccinated: VACCECON_W83

econimpact = pewdata.VACCECON_W83.value_counts()
econimpact
```




    Help the economy a lot           6058
    Help the economy a little        2304
    Not make much of a difference    1620
    Refused                           139
    Name: VACCECON_W83, dtype: int64




```python
#normalizing and rounding these numbers 
econimpact = pewdata.VACCECON_W83.value_counts(normalize = True).round(2)
econimpact
```




    Help the economy a lot           0.60
    Help the economy a little        0.23
    Not make much of a difference    0.16
    Refused                          0.01
    Name: VACCECON_W83, dtype: float64




```python
# pie chart using pandas series plot()

pewdata.VACCECON_W83.value_counts().plot(kind='pie', title = 'Respondent View: Economic Impact if Majority of Americans Vaccinated',colors = ["cornflowerblue", "lavender", "lightblue", "wheat"], autopct = '%1.1f%%' , labeldistance=None).legend(loc = 'lower right')



```




    <matplotlib.legend.Legend at 0x7fc2c4ed6af0>




    
![png](output_10_1.png)
    



```python
pewdata.SC1_W83.value_counts(normalize = True).round(2)
```




    Mostly positive                        0.74
    Equal positive and negative effects    0.21
    Mostly negative                        0.04
    Refused                                0.01
    Name: SC1_W83, dtype: float64



## Relationship Between View of COVID-19 Vaccine Impact on Economy and Effect of Science on Society

In the same pew report as above, the following question was asked: 
Overall, would you say science has had a mostly positive effect on our society or a mostly negative effect on our society?

1 Mostly positive

2 Mostly negative

3 Equal positive and negative effects

This is denoted by the variable SC1 in the codebook, SC1_W83 in the pewdata dataset


```python
#rearrange the axes from science positive to science negative, help economy a lot to not make a difference
```


```python
pd.crosstab(pewdata.SC1_W83, pewdata.VACCECON_W83, normalize = 'index').round(2).reindex(['Mostly positive', 'Equal positive and negative effects','Mostly negative', 'Refused'])[['Help the economy a lot', 'Help the economy a little', 'Not make much of a difference', 'Refused']]

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>VACCECON_W83</th>
      <th>Help the economy a lot</th>
      <th>Help the economy a little</th>
      <th>Not make much of a difference</th>
      <th>Refused</th>
    </tr>
    <tr>
      <th>SC1_W83</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Mostly positive</th>
      <td>0.69</td>
      <td>0.21</td>
      <td>0.09</td>
      <td>0.01</td>
    </tr>
    <tr>
      <th>Equal positive and negative effects</th>
      <td>0.34</td>
      <td>0.29</td>
      <td>0.35</td>
      <td>0.02</td>
    </tr>
    <tr>
      <th>Mostly negative</th>
      <td>0.23</td>
      <td>0.26</td>
      <td>0.49</td>
      <td>0.02</td>
    </tr>
    <tr>
      <th>Refused</th>
      <td>0.45</td>
      <td>0.25</td>
      <td>0.24</td>
      <td>0.06</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
